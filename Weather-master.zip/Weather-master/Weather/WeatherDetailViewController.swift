//
//  WeatherDetailViewController.swift
//  Weather
//
//  Created by Rashid on 14/06/2019.
//  Copyright © 2019 Softizo. All rights reserved.
//

import UIKit
import SDWebImage

class WeatherDetailViewController: UIViewController {
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var wetherDetailLabel: UILabel!
    @IBOutlet weak var tempratureLabel: UILabel!
    @IBOutlet weak var windLabel: UILabel!
    @IBOutlet weak var cloudLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    
    var weatherObj : List!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.largeTitleDisplayMode = .never
        self.title = "Weather Details"
        setupUI()
    }

    func setupUI(){
        self.cityLabel.text = weatherObj.name
        self.wetherDetailLabel.text = weatherObj.weather[0].weatherDescription.capitalized
        self.tempratureLabel.text = "\(round(weatherObj.main.temp))"
        self.windLabel.text = "\(weatherObj.wind.speed)%"
        self.cloudLabel.text = "\(weatherObj.clouds.all)%"
        self.humidityLabel.text = "\(weatherObj.main.humidity) km/h"
        
        let url = "http://openweathermap.org/img/w/\(weatherObj.weather[0].icon).png"
        let image_url = URL(string: url)
        weatherIcon.sd_imageIndicator = SDWebImageActivityIndicator.gray
        weatherIcon.sd_setImage(with: image_url) { (image, error, cache, url) in }
    }
}
