//
//  WeatherCell.swift
//  Weather
//
//  Created by Rashid on 14/06/2019.
//  Copyright © 2019 Softizo. All rights reserved.
//

import UIKit
import SDWebImage

class WeatherCell: UITableViewCell {

    @IBOutlet weak var wetherIcon: UIImageView!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var tempratureLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    var weatherObj : List! {
        didSet{
            let url = "http://openweathermap.org/img/w/\(weatherObj.weather[0].icon).png"
            let image_url = URL(string: url)
            wetherIcon.sd_imageIndicator = SDWebImageActivityIndicator.gray
            wetherIcon.sd_setImage(with: image_url) { (image, error, cache, url) in }
            
            self.cityLabel.text = weatherObj.name
            tempratureLabel.text = "\(round(weatherObj.main.temp))°"
        }
    }

}
