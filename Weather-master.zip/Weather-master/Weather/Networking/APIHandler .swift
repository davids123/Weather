//
//  APIHandler .swift
//  Scambiocorse
//
//  Created by Rashid on 14/06/2019.
//  Copyright © 2019 Softizo. All rights reserved.
//

import Foundation
import UIKit
import Alamofire

let urlString = "http://api.openweathermap.org/data/2.5/weather?q=islamabad&APPID=8529a2c48301a2cd7f717bf4d8280058"

class APIHandler {
    
    class func executeRequest( params : Parameters?, city: String ,completionHandler:@escaping ( _ data: Data?, _ error: String?)->Void) {
        
        let  postType = HTTPMethod.post
        
        let completerUrl = "http://api.openweathermap.org/data/2.5/group?id=\(city)&units=metric&APPID=8529a2c48301a2cd7f717bf4d8280058"
        
        Alamofire.request(completerUrl , method: postType, parameters: params, encoding: JSONEncoding.default, headers: nil)
            
            .responseString { (response) in
                print("responseString = \(response)")
            }
            
            .responseJSON { (response) in
                let httpStatusCode = response.response?.statusCode
                
                if response.result.isSuccess {
                    if (httpStatusCode == 200) {
                        
                        // Get the API data
                        if let data = response.data {
                            print(data)
                            completionHandler(data, nil)
                        } else {
                            completionHandler(nil, "Failed to load data")
                        }
                        
                    } else {
                        // Api failure response
                        let tempresponse = response.result.value as? [String: Any]
                        let errorMessage = tempresponse?["message"] as? String
                        completionHandler(nil, errorMessage)
                    }
                } else {
                    /// failed status code
                    guard let error = response.error?.localizedDescription else { return }
                    completionHandler(nil, error)
                    print(error)
                }
        }
    }
    
    
}


