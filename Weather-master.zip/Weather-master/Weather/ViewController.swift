//
//  ViewController.swift
//  Weather
//
//  Created by Rashid on 14/06/2019.
//  Copyright © 2019 Softizo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!{
        didSet {
            tableView.delegate = self
            tableView.dataSource = self
            tableView.tableFooterView = UIView()
        }
    }
    
    let citiesArray = "5101760,1850147,2643743"
    
    var weatherArray = [List]() {
        didSet{
            tableView.reloadData()
        }
    }
    let weatherCellID = "WeatherCell"
    override func viewDidLoad() {
        super.viewDidLoad()
        
        APIHandler.executeRequest(params: nil, city: citiesArray) { (data, error) in
            if let err = error {
                print(err)
            } else if let data = data {
                print(data)
                do {
                    let decodeData = try JSONDecoder().decode(WeatherModel.self, from: data)
                    print(decodeData)
                    self.weatherArray = decodeData.list
                } catch let error {
                    print(error)
                }
                
            }
 
        }
    }
    

}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return self.weatherArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: weatherCellID, for: indexPath) as! WeatherCell
        cell.weatherObj = self.weatherArray[indexPath.row]
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "WeatherDetailViewController") as! WeatherDetailViewController
        vc.weatherObj = self.weatherArray[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
